package com.example.retos345;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Retos345Application {

	public static void main(String[] args) {
		SpringApplication.run(Retos345Application.class, args);
	}

}
