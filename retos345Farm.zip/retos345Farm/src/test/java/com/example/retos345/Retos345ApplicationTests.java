package com.example.retos345;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Retos345ApplicationTests {

	@Test
	void contextLoads() {
	}

}
